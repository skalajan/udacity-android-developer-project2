package com.example.android.popularmovies;

/**
 * Constants accessed from multiple classes.
 */
public class Constants {
    /**
     * Key used to authenticate against API.
     *
     * TODO: REMOVE BEFORE SUBMITTING/ADD DURING EVALUATION !IMPORTANT
     */
    public static final String API_KEY = null;

    public static final String MOVIE_DETAILS_EXTRA = "movieDetailsExtra";
}
