package com.example.android.popularmovies.discovery;


public interface OnFirstLoadingFinishedListener {
    /**
     * Method triggered after the first load finished.
     */
    void onAfterFirstLoad();
}
