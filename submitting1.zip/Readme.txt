Project 1 - Popular Movies
Author - Jan Sk�la (kjs566@gmail.com)


!IMPORTANT -> Add your API key to access the www.themoviedb.org API before building the app. You can get the key after registration. The key has to be present at Constants.API_KEY.
 

Licences:

AppIcon
Icon of the movie camera used in the app icon was created by Catalin Fertu (http://www.flaticon.com/authors/catalin-fertu) from www.flaticon.com

LoadNextPageScrollListener
Based on "Endless RecyclerView OnScrollListener" created by WoongBi Kim (https://github.com/ssinss), available at https://gist.github.com/ssinss/e06f12ef66c51252563e
